// ------------------ Array Methods ------------------ \\
// Helps you get more out of arrays
// Arrays come with a few built-in methods 
// that make life easier. We're going to cover (7):
	// unshift/shift
	// push/pop
	// indexOf
	// slice
	// splice
// ---------------------------------------------------- \\


// Unshift and Shift ----------------------
// Use Unshift to add to the front of an array:
var colors = ["red", "orange", "yellow"];
colors.unshift("infrared")
// ["infrared", "red", "orange", "yellow"]

// Use shift to remove the first item in an array
var colors = ["red", "orange", "yellow"];
colors.shift();
// ["orange", "yellow"]
//shift() also returns the removed element
var col = colors.shift();  //orange
// ---------------------------------------


// Push and Pop --------------------------
// Use push to add to the end of an array:
var colors = ["red", "orange", "yellow"];
colors.push("green");
//["red", "orange", "yellow", "green"]

// Use pop to remove the last item in an array
var colors = ["red", "orange", "yellow"];
colors.pop();
//["red", "orange"]
//pop() also returns the removed element
var col = colors.pop();  //orange
// ---------------------------------------


// IndexOf  ---------------------------------------------------------------
// Use indexOf() to find the index of an item in an array
var friends = ["Charlie", "Liz", "David", "Mattias", "Liz"];
friends.indexOf("David"); //2
// indexOf() returns the first index at which a given element can be found
friends.indexOf("Liz"); //1, not 4
// indexOf() also returns -1 if the element is not present.
friends.indexOf("Hagrid"); //-1
// ------------------------------------------------------------------------


// Slice ---------------------------------------------------------------------
// Use slice() to copy parts of an array, such as the 2nd and 3rd items
var fruits = ['Banana', 'Orange', 'Lemon', 'Apple', 'Mango'];
// When using slice() you must specify the index 
// where the new array starts(1) and will end(3)
var citrus = fruits.slice(1, 3);
//this WILL NOT alter the original array
// Fruits will still contain ['Banana', 'Orange', 'Lemon', 'Apple', 'Mango'];
// But citrus will now contain ['Orange','Lemon']
// =========================================================================== 
// You can also use slice() to copy an entire array
var nums = [1,2,3];
var otherNums = nums.slice();
// otherNums now contains all elements of the nums array, 
// and therefore both arrays contain [1,2,3]
// ---------------------------------------------------------------------------


// Splice -----------------------------------------------------------------------------------
// Use splice to remove an element at index (x,y) from an array 
var fruits = ['Banana', 'Orange', 'Lemon', 'Apple', 'Mango'];
// ex) use splice to remove 'Orange' from the array
// specify index of the element to be removed and 
// how many elements to remove in total (starting from that specified index)
fruits.splice(1, 1);
// returns: ["Orange"]
console.log(fruits);
// prints: ["Banana", "Lemon", "Apple", "Mango"]
// ========================================================================================== 
// How about if I want to remove multiple elements starting from lets say.. the third index?
var fruits = ['Banana', 'Peach', 'Lemon', 'Orange', 'Apple', 'Plumb', 'Mango', 'Pear'];
fruits.splice(3, 4);
// returns: ["Orange", "Apple", "Plumb", "Mango"]
console.log(fruits);
// prints: ["Banana", "Peach", "Lemon", "Pear"]
// ------------------------------------------------------------------------------------------