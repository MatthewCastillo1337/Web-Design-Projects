// ----------------- FIRST PROBLEM ------------------------------------------
// This function will print every index in our array, from the last
// content in our index to the first.
function printReverse(arr){
	for(var i = arr.length -1; i >= 0; i--){
		console.log(arr[i]);
	}
}
printReverse(["Man","Eats","Dragon"]);
// I wanted to reverse the printReverse function to understand how it works
// Which is essentially just printing our array, in the order of which each
// index appears.
function printNorm(arr){
	for(var i = 0; i <= arr.length - 1; i++){
		console.log(arr[i]);
	}
}
printNorm(["Woman","Eats","Dragon"]);
// --------------------------------------------------------------------------


// ----------------- SECOND PROBLEM -----------------------------------------
// This function will return true only if every index of our array is 
// equal to the first index (or index[0])
function isUniform(arr){
	var first = arr[0];
	for(var i = 1; i < arr.length; i++){
		if(arr[i] !== first){
			return false;
		}
	}
	return true;
}
// copy this into console to test function: isUniform(["a","a","a"]);
// copy this into console to test function: isUniform(["a","b","c"]);
// --------------------------------------------------------------------------


// ----------------- THIRD PROBLEM ------------------------------------------
// This function will return the sum of all the elements within an array
function sumArray(arr){
	var sum = 0;
	arr.forEach(function(element){
		sum += element;
	});
	return sum;
}
// copy this into console to test function: sumArray([1,1,1]);
// --------------------------------------------------------------------------


// ----------------- FOURTH PROBLEM -----------------------------------------
function max(arr){
	var max = arr[0];
	for(var i = 1; i < arr.length; i++){
		if(arr[i] > max){
			max = arr[i];
		}
	}
	return max;
}
// copy this into console to test function: max([1,21,11]);
// --------------------------------------------------------------------------