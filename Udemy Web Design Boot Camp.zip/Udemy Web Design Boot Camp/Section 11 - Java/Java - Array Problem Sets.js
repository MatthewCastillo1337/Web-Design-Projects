var reverseIt = [1,2,3,4];
reverseIt.forEach(function(printReverse){
	console.log(reverseIt[0]);
});