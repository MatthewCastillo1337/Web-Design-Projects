//------ Javascript Arrays
//------ Our First Data Structure

//-- Objectives
	// Understand arrays conceptually
	// Write code using JS arrays

//Suppose I wanted to model a group of friends:
  //var friend1 = "Charlie";
  //var friend2 = "Liz";
  //var friend3 = "David";
  //var friend4 = "Mattias";
//---- This is a lot of code, and it doesn't let us group the friends together

// This is a perfect use case for an ARRAY
var friends = ["Charlie", "Liz", "David", "Mattias"];
// Arrays let us group data together in lists
// -- Arrays are indexed starting at 0.  Every slot has a corresponding number
  // Charlie -- index = 0
  // Liz     -- index = 1
  // David   -- index = 2
  // Mattias -- index = 3
// We can use those indices to retrieve data
console.log(friends[0])   //"Charlie"
friends[1] + " <3 " + friends[2]  //"Liz <3 David"
// We can also update arrays
friends[0] = "Chuck";
friends[1] = "Lizzie";
// We can also add new data
friends[4] = "Amelie"; // index 4 did not exist, but now we have Amelia 
					   // in our friends array
// Just a Last few things ---
//We can initialize an empty array two ways:
var friends = []; //no friends :(
var friends = new Array() //uncommon
//Arrays can hold any type of data 
// This array has a number, a boolean, a string, and a null.
var random_collection = [49, true, "Hermione", null]; 
//Arrays have a length property
var nums = [45,37,89,24];
nums.length   //4 ... The length is 4 because we have 4 indices
// But remember an index's value always starts at 0 for the 1st index.