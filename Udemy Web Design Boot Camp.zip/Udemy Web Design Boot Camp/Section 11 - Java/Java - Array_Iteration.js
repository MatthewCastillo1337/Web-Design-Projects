// --------------------------------------------------------
// For Loop
// To loop over an array using a for loop, 
// we need to make use of the array's  length property

var numbers = ["1", "2", "3", "4"];

for(var i = 0; i < numbers.length; i++) {
  console.log(numbers[i]);
}
// --------------------------------------------------------


// --------------------------------------------------------
// ForEach
// JavaScript provides an easy built-in way 
// of iterating over an array: ForEach
// ----- arr.forEach(someFunction) --------

var letters = ["A", "B","C", "D"];

letters.forEach(function(letter){
//color is a placeholder, call it whatever you want
  console.log(letter);
});
// --------------------------------------------------------


// --------------------------------------------------------
// For vs. ForEach
// The following 2 code snippets do the same thing:
//with a for loop
var tools = ["hammer", "screwdriver", "nail", "scissors"];

for(var i = 0; i < tools.length; i++) {
  console.log(tools[i]);
}
//using forEach
var tools = ["hammer", "screwdriver", "nail", "scissors"];

tools.forEach(function(tool){
  console.log(tool);
});
// --------------------------------------------------------


// --------------------------------------------------------
// NOTES FROM THE VIDEO
// FOR EACH LOOPS
letters.forEach(function(letter){
	console.log("The Alphabet Goes Like " + letter);
});
// new function
function printTool(tool){
	console.log("##########");
	console.log(tool);
	console.log("!!!!!!!!!!!");
}
printTool("wrench")

//instead of doing this ---> tools.forEach(function())
// we can do this     // and call our new function
tools.forEach(printTool); 
// which is iterated into our old tools array

// ----------------------------------------------------
// QUICK QUIZ
// What does the following code print out?
var numbers = [1,2,3,4,5,6,7,8,9,10];
var colors = ["red", "orange", "yellow", "green"];

numbers.forEach(function(color){
  if(color% 3 === 0) {
   console.log(color);
  }
});
// Should get 3,6,9


// Quick Exercise -- now rewrite this code to print out
// all numbers in an array that are evenly divisible by 3
// using a for loop instead of forEach
	// NOT CURRENTLY WORKING AS INTENDED
	// var numberz = [1,2,3,4,5,6,7,8,9,10];
	// for (var i = 0; i % 3 === 0; i++) {
	// 	console.log(numberz[i]);
	// }
// ----------------------------------------------------