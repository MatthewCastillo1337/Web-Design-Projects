// This is an array with multiple arrays inside of it
var friends = [
["Harry", "Ron", "Hermione"], 
["Malfoy", "crabbe", "Goyle"], 
["Mooney", "Wormtail", "Prongs"]
];
// Therefore when we want to console.log an index, you may not get what you expect.
console.log(friends[0]);
// Returns  ["Harry", "Ron", "Hermione"]
// Instead of just  ["Harry"] ---- like you would expect from a single array like this:
var xFriends = ["Harry", "Ron", "Hermione"]; 
console.log(xfriends[0]); // ["Harry"]
// This is further confusing when you are finding an index, inside an index, inside an index, etc.
// Example:
var animals = [
["Dog", "Bear", "Wolf"], 
["Cat", "Tiger", "Lion"], 
["Rat", ["Sewer_Rat", "Kitchen_Rat", "Pokemon_Rat"], "Mouse", "Hamster"]
];
console.log(animals[2]);
// Returns ["Rat", Array(3), "Mouse", "Hamster"]
console.log(animals[2][1]);
// Returns ["Sewer_Rat", "Kitchen_Rat", "Pokemon_Rat"]
console.log(animals[2][1][0]);
// Returns ["Sewer_Rat"]
console.log(animals[2][1][0][2]);
// Returns "w"