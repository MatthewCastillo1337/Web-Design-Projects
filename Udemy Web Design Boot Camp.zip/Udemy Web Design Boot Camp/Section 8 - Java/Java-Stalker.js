var firstName = prompt("Hello, what is your first name?");
var lastName = prompt("That's a great name! Now, what is your last name?");
var age = prompt("Fantastic! Last thing I need is your age, so if you don't mind, how old are you?");

// This is just preference, but it might be easier to put clunky information into its own variable
// And so you have...
var fullName = firstName + " " + lastName + ".";
// And...
console.log("Your full name is " + fullName);
// Instead of...
// THIS   ---> console.log("Your full name is " +  firstName + " " + lastName + ".");
console.log("You are " + age + " " + "years old.");
alert("Thank You So Much! That's all the information I needed from you, your results will print out below in the console log. Please open the console log in your browser to see your printed information. Thanks again!");
