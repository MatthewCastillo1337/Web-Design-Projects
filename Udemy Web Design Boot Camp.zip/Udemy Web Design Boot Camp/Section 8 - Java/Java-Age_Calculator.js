var ageCalculator = prompt("Please enter your age below.");
alert("You have been alive for roughly... " + (ageCalculator*365) + " days!");
var result = (ageCalculator*365) + " days!";
console.log("You entered "+ ageCalculator + " years old for your age." + " And so, " + ageCalculator + " X 365 Days = " + result + " ... (Roughly), That you have been alive!");
