var styles = {
    color: "red",
    background: "pink",
    border: "2px solid purple"
};

//Decorating our html with jQuery
$("h1").css(styles);

$("li").css({
    fontSize: "60px",
    border: "3px dashed purple",
    background: "rgba(89, 45, 20, 0.5)",
    color: "blue"
});

$("#special-li").css("color", "black");
