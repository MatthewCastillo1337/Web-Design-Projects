// Select all divs and give them a purple background
$("div").css("backgroundColor", "purple");
// Select all divs with class highlight and give them a width of 200px
$(".highlight").css("width", "200px");
// Select the div with an ID of third and give it an orange border
$("#third").css("border", "10px solid orange");
// Select only the FIRST DIV and change it's font color to pink
$("div:first-of-type").css("color", "pink");