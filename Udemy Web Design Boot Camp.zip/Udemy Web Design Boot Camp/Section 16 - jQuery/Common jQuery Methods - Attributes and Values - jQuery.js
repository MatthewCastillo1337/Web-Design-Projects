// FROM TEXT AND HTML jQuery Methods
		//Change the text content of the first html to "One Piece Fan Page" ---- And change the H2 to show more relevant content matching our H1
		$('h1').text("One Piece Fan Page"); $('h2').text("For True One Piece Fans");
		//Change the LIs of the UL on our page to some more constructive content relating to our H1 Element
		$("ul").html("<li>Name: Monkey D. Luffy</li><li>Devilfruit: Gomu Gomu No Mi</li>");
		//We can also add new html content to something in our page, such as:
		//Adding an anchor tag to the third LI in our UL
		$("ul").html("<li>Name: Monkey D. Luffy</li><li>Devilfruit: Gomu Gomu No Mi</li><li>One Piece Wiki: <a href='http://onepiece.wikia.com/wiki/One_Piece_Wiki'>CLICK HERE</a></li>");

//ATTRIBUTES AND VALUES
// ATTRIBUTES ---- ex) src --- Changing the img src to another hyperlink using jQuery
$('img').attr('src', 'https://ae01.alicdn.com/kf/HTB1pNZhgDAKL1JjSZFCq6xFspXaM/Monkey-D-Luffy-Cute-Cartoon-Stickers-One-Piece-Fixed-Gear-Luggage-Reusable-ONEPIECE-Refrigerator-Sticker.jpg_640x640.jpg');
// ATTRIBUTES ---- ex) input type --- Changing the input type value to something else
	// $('input').attr('type', 'color'); ------ OR ------- // $('input').attr('type', 'checkbox'); ------ //We had to comment this out since we are going to be using the original text input we set in our html
$("img").css("width", "400px");
$('img:nth-of-type(2)').attr('src', "https://ae01.alicdn.com/kf/HTB16VsAKXXXXXaKXFXXq6xXFXXXb/26cm-Monkey-D-Luffy-One-Piece-Jeans-PVC-Action-Figures-Model-Anime-Brinquedos-Toys.jpg_640x640.jpg");
$('img').last().attr('src', "https://banner2.kisspng.com/20180330/dqe/kisspng-monkey-d-luffy-roronoa-zoro-nami-t-shirt-one-piec-luffy-5abe1c4f84d069.723144291522408527544.jpg");
//change all images in img src at the same time
$('img').attr('src', 'https://i.imgur.com/zct0TqX.png');

// VALUES ---- ex) input --- Changing the input value of type text to something else:
$('input').val("WANTED!");
// VALUES ---- ex) select --- Changing the input value of a selection list to one of the items on the list:
$('select').val("$500 Mil Beli");