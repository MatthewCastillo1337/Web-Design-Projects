//Change the text content of the first html to "Common jQuery Methods"
$('h1').text("Common jQuery Methods");
//Change the LIs of the UL on our page to some more constructive errands
$("ul").html("<li>Finish doing laundry</li><li>Read Javascript Book</li><li>Make a track in Ableton</li>");
//We can also add new html content to something in our page, such as:
//Adding an anchor tag to the third LI in our UL
$("ul").html("<li>Finish doing laundry</li><li>Read Javascript Book</li><li><a href='https://www.ableton.com/en/packs/'>Make a track in Ableton</a></li>");