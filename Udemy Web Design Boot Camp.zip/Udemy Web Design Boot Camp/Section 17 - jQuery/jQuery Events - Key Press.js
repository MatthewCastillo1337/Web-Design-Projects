//Sends the console a message when keys are pressed in the input element
$('input').keypress(function(){
	console.log("You Pressed a Key!");
});

//Sends the browser an alert when the enter key is pressed in the input(text) element
$('input[type="text"]').keypress(function(event){
	if(event.which === 13){
		console.log("You have hit the enter Key!");
		alert("You have hit the enter Key!");
	}
});