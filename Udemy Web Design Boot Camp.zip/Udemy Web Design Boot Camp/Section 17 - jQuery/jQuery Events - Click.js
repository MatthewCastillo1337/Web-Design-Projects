$("button:nth-of-type(1)").click(function(){
	$('h3').removeClass("FunkyTwo");$('h3').removeClass("FunkyThree");
	$('h3').addClass("Funky");
	$('h3').html("<h1>DON'T PUSH THESE BUTTONS!</h1><h2>WHAT DID I JUST SAY!?</h2>");
	$("button:nth-of-type(1)").toggleClass("butt-on1");
	$("button:nth-of-type(1)").text("YAYYY!!!");
});
$("button:nth-of-type(2)").click(function(){
	$('h3').removeClass("Funky");$('h3').removeClass("FunkyThree");
	$('h3').addClass("FunkyTwo");
	$('h3').html("<h1>I WILL LITERALLY KILL YOU!!!</h1><h2>STOP PUSHING THESE FUCKING BUTTONS!?</h2>");
	$("button:nth-of-type(2)").toggleClass("butt-on2");
	$("button:nth-of-type(2)").text("YIPPIEEE!");
});
$("button:nth-of-type(3)").click(function(){
	$('h3').removeClass("Funky");$('h3').removeClass("FunkyTwo");
	$('h3').addClass("FunkyThree");
	$('h3').html("<h1>I AM BEGGING YOU....</h1><h2>P_L_E_A_S_E --- S_T_O_P!</h2>");
	$("button:nth-of-type(3)").toggleClass("butt-on3");
	$("button:nth-of-type(3)").text("HAHAHAHA!");
});
	// $(this).html("blahblah"); You must use $(this) and not just the vanilla js "this"