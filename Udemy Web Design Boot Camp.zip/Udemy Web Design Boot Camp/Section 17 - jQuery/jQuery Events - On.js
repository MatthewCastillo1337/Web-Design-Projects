//Function to change color of h1 on "click"
$("h1").on("click", function(){
	$(this).toggleClass("lowlight");
});
//Function to change color of h2 on "click"
$("h2").on("click", function(){
	$(this).toggleClass("highlight");
});
//Function to change colors of H3 with text input in our input element
$("input").keypress(function(event){
	//Key Press W
	if(event.which === 87){
		$('h3').addClass("key-W")
		$('h3').removeClass("key-A")
		$('h3').removeClass("key-S")
		$('h3').removeClass("key-D")
		$('h3').removeClass("key-Q")
		$('h3').removeClass("key-E")
		$('h3').removeClass("Enter")
	}
	//Key Press A
	else if(event.which === 65){
		$('h3').addClass("key-A")
		$('h3').removeClass("key-W")
		$('h3').removeClass("key-S")
		$('h3').removeClass("key-D")
		$('h3').removeClass("key-Q")
		$('h3').removeClass("key-E")
		$('h3').removeClass("Enter")
	}
	//Key Press S
	else if(event.which === 83){
		$('h3').addClass("key-S")
		$('h3').removeClass("key-A")
		$('h3').removeClass("key-W")
		$('h3').removeClass("key-D")
		$('h3').removeClass("key-Q")
		$('h3').removeClass("key-E")
		$('h3').removeClass("Enter")
	}
	//Key Press D
	else if(event.which === 68){
		$('h3').addClass("key-D")
		$('h3').removeClass("key-A")
		$('h3').removeClass("key-S")
		$('h3').removeClass("key-W")
		$('h3').removeClass("key-Q")
		$('h3').removeClass("key-E")
		$('h3').removeClass("Enter")
	}
	//Key Press Q
	else if(event.which === 81){
		$('h3').addClass("key-Q")
		$('h3').removeClass("key-A")
		$('h3').removeClass("key-S")
		$('h3').removeClass("key-D")
		$('h3').removeClass("key-W")
		$('h3').removeClass("key-E")
		$('h3').removeClass("Enter")
	}
	//Key Press E
	else if(event.which === 69){
		$('h3').addClass("key-E")
		$('h3').removeClass("key-A")
		$('h3').removeClass("key-S")
		$('h3').removeClass("key-D")
		$('h3').removeClass("key-Q")
		$('h3').removeClass("key-W")
		$('h3').removeClass("Enter")
	}
	//Key Press Enter
	else if(event.which === 13){
		$('h3').addClass("Enter")
		$('h3').removeClass("key-A")
		$('h3').removeClass("key-S")
		$('h3').removeClass("key-D")
		$('h3').removeClass("key-Q")
		$('h3').removeClass("key-E")
		$('h3').removeClass("key-W")
	}
});
//Function to change properties of h4 on mousehover
$("h4").on("mouseenter", function(){
	$(this).css("font-weight", "bold");
});
$("h4").on("mouseleave", function(){
	$(this).css("font-weight", "normal");
});