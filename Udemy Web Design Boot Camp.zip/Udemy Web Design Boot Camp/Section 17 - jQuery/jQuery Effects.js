// ------------------------------------------------------------------------------------------------------------------------------------------------------------
//fadeOut Function
$('button:nth-of-type(1)').on('click', function(){
	$('.fade-Out').fadeOut(200, function(){
		//having the remove function here will ensure that the code will not be executed until the fadeOut function is complete
		//also the remove function will completely remove the divs from the page, instead of just setting their display to none,
		//as the fadeOut function normally does.
			// $(this).remove();
	});
	//placing the remove function here will instantly execute the remove function and 
	//will NOT wait to exeucte the remove function, until after the fadeOut function is complete
});

//fadeIn Function
$('button:nth-of-type(2)').on('click', function(){
	$('div').addClass('fade-In');
	$('div').fadeIn(2000, function(){
	});
});

//fadeToggle Function (which makes the two effects above much simpler, however you can't have two different time values for fadeIn/fadeOut like you can above)
$('button:nth-of-type(3)').on('click', function(){
	$('div').fadeToggle(200, function(){
	});
});
// ------------------------------------------------------------------------------------------------------------------------------------------------------------


// ------------------------------------------------------------------------------------------------------------------------------------------------------------
//slideDown Function (Display must be set to none:)
$('button:nth-of-type(4)').on('click', function(){
	$('div').addClass('fade-In');
	$('div').slideDown(1000, function(){
	});
});
//slideUp Function (Display must NOT be set to none:) 
$('button:nth-of-type(5)').on('click', function(){
	$('div').removeClass('fade-In');
	$('div').slideUp(500, function(){
	});
});
//slideToggle Function (which makes the two effects above much simpler, however you can't have two different time values for slideUp/Down like you can above)
$('button:nth-of-type(6)').on('click', function(){
	$('div').slideToggle(200, function(){
	});
});
// ------------------------------------------------------------------------------------------------------------------------------------------------------------