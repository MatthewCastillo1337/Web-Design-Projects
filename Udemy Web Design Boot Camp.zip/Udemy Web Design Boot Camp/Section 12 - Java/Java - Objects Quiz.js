var someObject = {
	friends: [
	{name: "Malfoy"},
	{name: "Crabbe"},
	{name: "Goyle"},
	],
	color: "baby blue",
	isEvil: true
};
