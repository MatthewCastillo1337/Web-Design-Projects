var comments = {};
comments.data = ["Nice!", "Awesome Job!", "Great Work!"];
// This is calling the comments var to see what was inside it
comments
// This was the old way of us printing functions with arrays inside them
// We were defining this way in the "Global Name Space"
function print(arr){
	arr.forEach(function(el){
		console.log(el);
	})
}
// But it was outside of our comments namespace, and thus
// required us to pass in "comments.data" into our print function like so
print(comments.data);

// But now we can share the data of our array, 
// and use comments.data inside comments.print
// by using the "this" keyword in Javascript
comments.print = function(){
	this.data.forEach(function(el){
		console.log(el);
	});
}
// Hit enter and you will see:
		// function (){
		// 	this.data.forEach(function(el){
		// 		console.log(el);
		// 	})
		// }
// Now lets see what comments var looks like now, by typing:
comments
// This will print each index of the array inside comments
comments.print()