function speak() {
	return "WOOF!";
}
// speak()
// Will return "WOOF!", but if we wanted "MEOW!" we could change the return value
// of the function, but everytime we call our speak() function we will get "MEOW!"
// instead of "WOOF!", so to avoid this issue we should be...
//Writing it this way to avoid namespace collisions

var dogSpace = {};
var catSpace = {};

dogSpace.speak = function() {
	return "WOOF!";
}
catSpace.speak = function() {
	return "MEOW!";
}
// Now, when we call speak() we must call it using the var name.function (or method)
// So in this case, dogSpace.speak() or catSpace.speak()