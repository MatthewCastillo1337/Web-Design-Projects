// This is the way I thought he wanted us to do this... -------------------------------------------------------
var animeObjects = {
	anime: [" Naruto", " One Piece", " Bleach", " My Hero Academia", " Black Clover", " Hunter X Hunter"],
	rating: [" - 4.4 stars", " - 5.0 stars", " - 4.2 stars", " - 4.8 stars", " - 4.6 stars", " - 4.7 stars"],
	hasWatched: ["You have watched:", "You have not seen:", "Your favorite anime is:"]
};

animeObjects.hasWatched[2] + animeObjects.anime[1] + animeObjects.rating[1];
// -----------------------------------------------------------------------------------------------------------
// This is the way I should have done it! ----------------------------------------
var animes = [
	{
	title: "One Piece",
	seen: true,
	rating: 5
	},
	{
	title: "My Hero Academia",
	seen: true,
	rating: 4.9
	},
	{
	title: "Black Clover",
	seen: false,
	rating: 4.8
	}
]
// Calls the animes array, but does not execute any code 
animes

animes.forEach(function(anime){
	var result = "You have ";
	if(anime.seen){
		result += "seen ";
	} else {
		result += "not seen ";
	}
	result += "\"" + anime.title + "\" - ";
	result += anime.rating + " stars";
	console.log(result)
})
// --------------------------------------------------------------------------