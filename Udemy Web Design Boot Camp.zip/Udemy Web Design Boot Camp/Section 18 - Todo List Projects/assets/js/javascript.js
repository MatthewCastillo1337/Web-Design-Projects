//check off specific todos by clicking
$('li').click(function(){
	$(this).toggleClass('completed');	
});

//click on X to delete todo
	// $('span').click(function(){
	// 	alert('clicked on a span!');
	// });
//this span is inside an <li> which is inside an <ul> 
//inside a <div #container> inside a <body> inside <html>
//so technically it has the potential to click on multiple scopes
//which is why our li gets crossed out and turns brown
//and if we had other functions/css/events for any other element
//within that scope, those would also activate
//which is not what we want, so we must refactor it like this:
$('span').click(function(event){
	$(this).parent().fadeOut(200, function(){
		$(this).remove();
	});
	event.stopPropagation();
});
//and now when we click the "X", only the fadeOut activates 
//without any other function executing
//(like the li crossing out and turning brown)