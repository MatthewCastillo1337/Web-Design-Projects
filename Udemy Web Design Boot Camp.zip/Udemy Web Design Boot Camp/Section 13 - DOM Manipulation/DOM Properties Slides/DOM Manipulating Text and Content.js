// THESE CODES WILL NOT WORK because they are not actually attached to something
// But this is just to explain the difference of innerHTML and textContent
// Here textContent will literally type in plain font "<h1>Goodbye!</h1>"
// in your browser. 
document.body.textContent = "<h1>Goodbye!</h1>";
// Versus innerHTML
document.body.innerHTML = "<h1>Goodbye!</h1>";
// which will actually render as an h1 tag

// If you wanted to replace the content of lets say a paragraph, 
// you can use textContent to replace that content
var p = document.querySelector("p");
p.textContent
//"Bulldogs are the best dog breed!" textContent can replace this:
p.textContent = "Pitbulls are the best dog breed!"
// BUT we have to be careful using it because it will erase and bypass
// any elements that were within our tag
// ex, <p>Cats are the <strong>FUNNIEST</strong> animals on the planet!</p>
// textContent will completely override the strong element and just type in
// whatever we set the textContent to be
// A way to counteract this is by using innerHtml
p.innerHTML
//"Pitbulls <b>are</b> the <strong>best</strong> dog breed!"
// BUT we still have to write out the tags that existed before changing our text
p.innerHTML = "Pitbulls <b>are</b> the <strong>best</strong> dog breed!"
// Otherwise if we do this:
p.innerHTML = "Pitbulls are the best dog breed!"
// It will do the same thing as textContent

//AND REMEMBER we can not use textContent to preserve the html
// and thus do the same thing we just did with innerHTML, 
// for ex, We can't do this:
p.textContent = "Pitbulls <b>are</b> the <strong>best</strong> dog breed!"
// because we will just get "Pitbulls <b>are</b> the <strong>best</strong> dog breed!"
// but not rendered as we do with innerHTML, 
// instead we will get the literal text of our tags