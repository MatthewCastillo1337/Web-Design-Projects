// Exercise 1 - Come up with 4 diff ways to select the first <p> tag
// I came up with at least six
var oneP = document.getElementById("first");
var twoP = document.getElementsByClassName("special")[0];
var threeP = document.querySelector("#first");
var fourP = document.querySelector("p");
var fiveP = document.querySelector("p#first");
var sixP = document.querySelector("p#first.special");
// I realized more ways of doing this after watching the video
var sevenP = document.querySelector(".special");
var eightP = document.querySelectorAll(".special")[0];
var nineP = document.getElementByTagName("p")[0];
// There are a ton more ways to do the same thing, ex:
var tenP = document.querySelectorAll("p")[0];
var ellevenP = document.querySelector("h1 + p");
// And more and more ways... you just have to be creative