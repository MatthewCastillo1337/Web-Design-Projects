// VERY IMPORTANT TO NOTE:
// These are Javascript objects that are constructed from our HTML,
// They are IN NO WAY html!

// This will select the Element who's ID is equal to "highlight"
var tag = document.getElementById("highlight");
// This will select all Elements who's classes are equal to "bolded"
var tags = document.getElementsByClassName("bolded");
tags[0]
tags[1]
// This will select all Elements by the tag of "li"
var tagz = document.getElementsByTagName("li");
tagz
// This will select all Elements by the tag of "body", which is only One,
// thus index[0]
var body = document.getElementsByTagName("body")[0];
body
// This will select all Elements by the tag of "h1"
var h1s = document.getElementsByTagName("h1");
h1s
// QUERY SELECTOR WILL ONLY RETURN THE FIRST MATCH
// IT IS USED TO RETURN A GIVEN CSS-STYLE SELECTOR
// Unlike getElementsBy which returns a given selector (not specific to CSS)
// This will select only the first Element with the tag of "h1"
var h1 = document.querySelector("h1");
h1
// This will select the Element with the ID of "highlight"
// Remember an ID can only be assigned once to a tag
var li = document.querySelector("#highlight");
li
// This will select only the first Element with the Class of "bolded"
var li2 = document.querySelector(".bolded");
li2
// IF YOU TRY to do
// var li2 = document.querySelector(".bolded")[1];
// In order to select the second element who's class is also "bolded"
// This will NOT work because QUERY SELECTOR WILL ONLY RETURN THE FIRST MATCH
// THE ALTERNATIVE IS - querySelectorAll
// which returns a list of all elements that matches a CSS-style selector
var all_Lis = document.querySelectorAll("li");
all_Lis
// querySelectorAll will select all Elements with class of "bolded"
var all_Classes = document.querySelectorAll(".bolded");
all_Classes
// Compared to just querySelector, 
// which will select the first Element with class of "bolded"
var firstClass = document.querySelector(".bolded");
firstClass
// Something that can seem a little tricky is when you use querySelectorAll
// But you only have 1 matching result for that selector because only one
// actual Element by that tag name exists, such as with an ID
var Id = document.querySelectorAll("#highlight");
Id
// In this case it is better/correct to just use querySelector
// Even if querySelectorAll will also work
var ID = document.querySelector("#highlight");
ID
// But it is better to use querySelectorAll if you have an Element
// that can appear more than once, such as with a Class tag
var All_Classes = document.querySelectorAll(".bolded");
All_Classes