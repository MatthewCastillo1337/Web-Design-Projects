// This is a for loop --- Which is written shorter than 
// the while loop code of its equivalance. Here the var
// can be written to exist only inside of the loop (unlike a while loop)
for(var count = 0; count < 6; count++) {
	console.log(count);
}
// This is a While Loop -- which takes more time to write than the for loop
// and requires a var to be declared seperately outside of the loop
var count = 1;

while(count < 6) {
	console.log("count is: " + count);
	count++;
}

// This is another example comparing a for loop to a while loop
// for loop
var str = "hello";
for(var i = 0; i < str.length; i++){
	console.log(str[i]);
}

// while loop
var str = "hello";
var count = 0;

while(count < str.length) {
	console.log(str[count]);
	count++;
}
