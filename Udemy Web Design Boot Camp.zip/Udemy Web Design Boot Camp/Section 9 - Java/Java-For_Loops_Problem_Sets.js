// Print All Numbers between -10 and 19
for(i = -10; i < 20; i++) {
	console.log(i);
}
// Print All Even Numbers between 10 and 40
for(i = 10; i <= 40; i += 2) {
	console.log(i);
}
// Print All Odd Numbers between 300 and 333
for(i = 300; i <= 333; i++) {
	if(i % 2 !== 0)
	console.log(i);
}
// Print All Numbers divisible by 5 AND 3 between 5 and 50
for(i = 5; i <= 50; i++) {
	if(i % 5 === 0 && i % 3 === 0)
	console.log(i);
}