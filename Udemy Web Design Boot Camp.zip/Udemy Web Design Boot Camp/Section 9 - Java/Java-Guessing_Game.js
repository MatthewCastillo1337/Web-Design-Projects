//create a secret number
var secretNumber = 23

//ask user for guess
var stringGuess = prompt("Guess a number");
var guess = Number(stringGuess);

//check if guess is right
if(guess === secretNumber) {
	alert("YOU GOT IT RIGHT!");
}

//check if guess is higher or lower, then ask user to guess again
while(guess < secretNumber || guess > secretNumber){
	if(guess < secretNumber){
	alert("Too low. Guess again!");		
	}
	if(guess > secretNumber){
	alert("Too high. Guess again!");		
	}
	var stringGuess = prompt("Guess again!");
	var guess = Number(stringGuess);
	if(guess === secretNumber) {
	alert("YOU GOT IT RIGHT!");
	}
}