// -------- AGE EXERCISES ----------- \\
// Creating the Age variable 
// And converting prompt to a number (using Number(prompt))
// since Prompt always returns a string
var age = Number(prompt("How old are you?"));
// Error Message for negative inputs (for age)
if (age < 0){
	alert("ERROR! Age must be greater than or equal to 0!");
	console.log("ERROR! Age must be greater than or equal to 0!");
}
// Happy B-DAY Message for when Age = 21
else if (age === 21){
	console.log("Happy 21st Birthday!!!");
}
// A Message for ages that are perfect squares
else if (age % Math.sqrt(age) === 0) {
  console.log("Your Age is a perfect square!");
}
// A Message for ages that are odd numbers 
// (but not 21 since the previous else statement will over-ride this one)
else if (age % 2 !== 0){
	console.log("Your Age is an Odd Number!");
}
// A Message for ages that are even numbers 
else {
	console.log("Your Age is an Even Number!");
}

// ---------- SOLUTION -----------
// Get age and convert it to a Number (prompt always returns a String)
	// var age = Number(prompt("What is your age?"));
	 
	// // If age is negative
	// if(age < 0) {
	//  console.log("Come back once you're out of the womb");
	// }
	 
	// // If age is 21  
	// if(age === 21) {
	//  console.log("Happy 21st Birthday!");
	// }
	 
	// // If age is odd
	// //(not evenly divisible by two)
	// if(age % 2 !== 0) {
	//  console.log("Your age is odd!");
	// }
	 
	// // If age is a perfect square
	// if(age % Math.sqrt(age) === 0) {
	//   console.log("Your age is a perfect square!");
	// }