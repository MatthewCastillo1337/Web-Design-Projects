var question = Number(prompt("Guess a number from 0 to 20")); 
if (question === 11){
	alert("Awesome job! You guessed the right number!")
	alert("Refresh the page to play again.")
}
else if (question < 0 || question > 20){
	alert("YOU MUST GUESS A NUMBER BETWEEN 0 AND 20!")
	alert("Refresh the page to play again.")
}
else if(question >= 0 || question < 11 || question > 11){
	alert("Sorry, you guessed wrong.")
	alert("Refresh the page to play again.")
}