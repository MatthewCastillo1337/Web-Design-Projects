// Print All Numbers between -10 and 19
var count = -10;

while(count < 20) {
 console.log(count);
 count++;
}
// Print All Even Numbers between 10 and 40
var count = 10;

while(count <= 40) {
 console.log(count);
 count+=2;
}
// Print All Odd Numbers between 300 and 333
var count = 300;

while(count <= 333) {
 if(count % 2 !== 0){
 	console.log(count);
 }
 count+=1;
}
// Print All Numbers divisible by 5 AND 3 between 5 and 50
var count = 5;

while(count <= 50) {
 if(count % 5 === 0 && count % 3 === 0){
 	console.log(count);
 }
 count+=1;
}