var button = document.querySelector("button");

// var isRed = false;
//1st way of doing this
		// button.addEventListener("click", function(){
		// 	if (isRed){
		// 	document.body.style.background = "white";
		// 	isRed = false;	
		// 	} else {
		// 		document.body.style.background = "Red";
		// 		isRed = true;
		// 		}
		// })
//2nd way of doing this
		// button.addEventListener("click", function(){
		// 	if (isRed){
		// 	document.body.style.background = "white";
		// 	} 
		// 	else {
		// 	document.body.style.background = "Red";
		// 	}
		// 	isRed = !isRed;
		// })
		
//3rd way of doing this - BEST PRACTICE
button.addEventListener("click", function(){
	document.body.classList.toggle("red");
});