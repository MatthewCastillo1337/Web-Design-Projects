//selecting the first h1 in our document
var h1 = document.querySelector("h1");
//test to see if h1 was selected
h1
//adding an event listener for whenever we click on the h1 element
// Now when we click on our h1, we will get an alert
h1.addEventListener("click", function(){
	alert("H1 was clicked!");
})
//added an event listener to change the background color
//of our h1 to blue "on click"
h1.addEventListener("click", function(){
	h1.style.background = "blue";
})
//added an event listener to print to our console a message
//for everytime we click the <ul>
document.querySelector("ul").addEventListener("click", function(){
	console.log("You Clicked The UL!");
})
//selected all lis in our doc
var lis = document.querySelectorAll("li");
//test to see if all lis were selected
lis
//added an event listener to each li to
for(var i = 0; i < lis.length; i++){
	lis[i].addEventListener("click", function(){
		this.style.color = "red";
	});
}