// ---------- // JAVASCRIPT FUNCTIONS EXAMPLE
function doSomething() {
	console.log("Hello World");
}

// I could then call this code by typing:
doSomething();
// And I can call it as many times as I want, over and over again:
doSomething();
doSomething();
doSomething();

//----------------- // HERE IS ANOTHER EXAMPLE

// Here I create a function called "singSong":
function singSong() {
	console.log("Twinkle, twinkle, little star,");
	console.log("How I Wonder what you are!");
	console.log("Up above the world so high,");
	console.log("Like a diamond in the sky.");
}
// Then I call the function by typing its name below:
singSong();