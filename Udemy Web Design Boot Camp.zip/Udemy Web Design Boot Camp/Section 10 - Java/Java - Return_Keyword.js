// THE RETURN KEYWORD \\
// We use the return keyword to output a value, from a function
// We can Now call that "return keyword" and 
// use it in any of our functions, or store it in any of our other variables
// ONCE WE DECLARE A "return" output, the function ends, unless if under if/else statements.


// FIRST EXAMPLE \\ ----------------------------------------------------------------
//this function capitalizes the first char in a string:
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

var city = "paris";              //"paris"
var capital = capitalize(city);  //"Paris"
//we can capture the returned value in a variable (as shown with our var "capital")
// ----------------------------------------------------------------------------------


// SECOND EXAMPLE \\ ----------------------------------------------------------------
// The return keyword stops execution of a function
// Here we create the function
function capitalize(str) {
// Here we tell our function to return an error message 
// if the user types in a number instead of a string
  if(typeof str === "number") {
    return "that's not a string!"
  }
// Here we declare a return value for when the user types in a string
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// Below we implement our "return key" within a stored variable
// The first one will work because our variable is equal to a string
var city = "paris";              //"paris"
var capital = capitalize(city);  //"Paris"
// These next lines will not work because our variable is = to a number, not a string.
var num = 37;           
var capital = capitalize(num);  //"that's not a string!"
// ----------------------------------------------------------------------------------


// ANOTHER SYNTAX \\ -----> Function Declaration -- VS -- Function Expression -------

//function declaration
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
       // VS

//function expression
var capitalize = function(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
// ----------------------------------------------------------------------------------
