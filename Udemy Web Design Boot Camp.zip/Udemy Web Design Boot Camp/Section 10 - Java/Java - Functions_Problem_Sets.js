// PROBLEM SET # 1 ----------------------------------------------
// Write a function that takes a single numeric argument
// and returns true if the number is even, and false otherwise.
            
// L O N G E R  --- C O D E
function isItEven(num) {
	if(num % 2 === 0){
		return true;
	}
	else {
		return false;
	}
}
// S H O R T E R ---- C O D E ---- *** BETTER CHOICE
function isEven(num) {
	return num % 2 === 0;
}
// --------------------------------------------------------------




// PROBLEM SET # 2 ----------------------------------------------
// Write a function that takes a single numeric argument
// and returns the factorial of that number.

// REVERSE FACTORIAL ---- 1 x 2 x 3 x 4 --- > *** BETTER CHOICE
function revFactorial(num){
	var result = 1;
	for(var i = 2; i <= num; i++){
		result *= i;
	}
	return result;
}

			// V E R S U S

// FACTORIAL ---- 4 x 3 x 2 x 1 --- >
function factorial(num){
	var result = num;
	for(var i = num - 1; i >= 1; i--){
		result *= i;
	}
if (num === 0) {return 1;}
	return result;
}
// --------------------------------------------------------------




// PROBLEM SET # 3 ----------------------------------------------
// Write a function that takes a single kebab-cased string argument
// and returns the snake_cased version of the string.
function kebabToSnake(str) {
var newStr = str.replace(/-/g , "_");
return newStr;
}
// --------------------------------------------------------------