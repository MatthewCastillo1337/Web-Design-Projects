// Often we want to write functions that take inputs
// Here is an example
function square(num) {
	console.log(num * num);
}
// Now when we call our function called "square" we need to pass in a value
// for the "num" part ... below are 3 examples of values we can put in for "num"
square(10);
square(3);
square(4);

// Here is another example for using an Argument
// First we create the function called "sayHello"
// then the Argument called "name"
// And we console log a message that will print some text 
// and whatever the value of name is
function sayHello(name) {
	console.log("Hello there " + name + "!");
}
// Here we give name a value using a string, 
// but we could have used a number, or something else
sayHello("Tupac");
sayHello("Biggie");
sayHello("Matthew");

// -------- FUNCTIONS CAN HAVE MULTIPLE ARGUMENTS ------
// Example 1
function area(length, width) {
	console.log(length * width);
}

area(9,2);

// Example 2
function greeting(personOne, person2, PersonThree) {
	console.log("Hi " + personOne);
	console.log("Hello " + person2);
	console.log("What's Up " + PersonThree);
}
greeting("Matt", "Bea", "Ms.Cruz");
// Remember Javascript is CASE sensitive, so everything must be written exact
// The name Jack and JACK, are completely different to Javascript
// so for a function value or an argument value to be called upon correctly, 
// the name must be written exactly as it is typed. "Jack + Jack" not "Jack + JACK" 

// Example 2 - What happens if you don't give a value to all the arguments
function greeting(personOne, personTwo, personThree) {
	console.log("Hi " + personOne);
	console.log("Hello " + personTwo);
	console.log("What's Up " + personThree);
}
greeting("Matt", "Bea");
// You get the console.log for the last value we did not define as "What's Up undefined"