// ---- A -- B U N C H -- O F -- N O T E S ------------------------------------------ \\
// Here you are simply defining a function called "doMath", it has not been run
// it has only been defined
function doMath(){
	var x = 40;
	console.log(x);
}
// Here the function "doMath" is finally being runned
doMath() // And 40 would be the result of this function
// since the console.log is running x, and x = 40

// However! When trying to run "x" outside of the defined function "doMath()"
x 
// You get an error because "x" is only defined within the "scope" of ...
// the CHILD element (or function) called "doMath", but not anywhere else outside 
// the function.  // NOW to fix this we can define "x" outside the function, as such...
var x = "hello"
// but now when we run "x"
x // we get back "hello" because "x" is defined 
// in the PARENT element as a VARIABLE (string) called "hello"
// And so when we run our "doMath()" equation
doMath() // We get --> 40, because the variable "x" is = 40 in the child (and more)
// specific function called "doMath" 

// WE CAN ALWAYS call a variable from a parent element inside a child element
// But we can not call an element from a child element within a parent element
// Here is an example ---

var y = 99; // here we defined a var called Y in the parent scope (= to 99)
y // here we are calling y, and our result is 99, from the parent scope
function callParent(){    // Now we are defining a child function/scope
	console.log(y);       // And setting this function to call the parent var y
}                         
						  // When we run this element
callParent()              // We get our y from the parent element which is 99

function callParent(){    // BUT if we change the value of the y var within our 
	y = 100;              // child function, without creating a new var
	console.log(y);       // the parent function will also change.
}

y // so when we call y here, y will still be 99 from the parent element 
// BECAUSE we havent ran our child element yet, we have only defined it so far.
// However when we run our child element ... the parent's value for "y" also changes
callParent() // And y now equals 100 (from the child element).

// The only way the parent's value for "y" wouldn't have changed is if the child 
// function created its' own variable for "y" instead of using the parent's y variable
// EXAMPLE ---> 
function call_Parent(){
	var y = 100;          // here a new variable y is defined, which is
	console.log(y);       // not the same as the parent's var y
}						  // And so, the var y (in the function "call_Parent")
						  // only exists within this child scope, but not anywhere else.
// ---- END -- O F -- FIRST -- 1/2 -- N O T E S ------------------------------------- \\

// Q U I C K ---- Q U I Z --------------------------------------------------------------
var num = 8;                // Here, we define the value "8" of a variable called num.
function do_Math(){ 		// Remember, here we have only DEFINED a function but it
	num += 1;				// HAS NOT yet run, until we execute or "CALL" the function
	if (num % 5 == 0){
		return true
	} else {
		return false
	}
} // ------------------->   // So num is still equal to 8, all the way to this point.
num += 1;					// And this code runs, making num, NOW equal to 9.
doMath()                    // AND FINALLY, our function "do_Math" runs, making num = 10
// SO WHAT WILL BE THE RESULT????
// THE ANSWER, of course is -----> TRUE 
// E N D ---- O F ---- Q U I Z -------------------------------------------------------\\

// ---- M O R E --- N O T E S ------------------------------------------------------- \\
// We can not, access a var from one function to another function
// Example BELOW
function hi(){
	var name = "Katey";  	// Here a var in a child element is defined
	console.log(name);      // this var only exists within this child function
}
                            // AND SO
function bye(){
	console.log(name);      // We will get an error for this second child function
}                           // when trying to call the var from the first child function
							// because we can't call a var from one child 
							// function to another.
// We would have to define a var called "name" in this second child function, but again
// it wouldn't be the same variable as the first child, because it is a completely 
// seperate variable that only exists within the second child element, but not
// anywhere else, including the first child function or other child elements.

//    AND  ---  MORE    +++++++++++++++++++++++++++++      NOTES           ---        \\

function sing(){                                    // Here we created a function
	console.log("That's My Dog!");
	console.log("And that's My Nigga, MEC!");
}

// This is a function that takes in another function, and an interval of time
setInterval(sing, 9000); // so here I placed my function sing, and
// set the time interval to 2000 milla-seconds or 2.0 seconds.
// You will get a return interval to stop setInterval from running constantly at
// every X interval you set it to, (in our case 2000).
// the code to stop the interval from running is "clearInterval();"

// We can also create a function inside setInterval, that will only exist within
// setInterval but will not exist outside of it, (like the last example we did).
// For example ----
setInterval(function song(){      // Here we created a function, that exists only in
	console.log("He's Gonna Hold It Down!"); // the function setInterval
	console.log("He's Gonna Hold It Down For the Real G's!");
}, 3000);